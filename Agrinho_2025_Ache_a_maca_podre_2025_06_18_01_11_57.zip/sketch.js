let balls = [];
let specialIdx;
let score = 0;
const r = 20;
const total = 40;

function setup() {
  createCanvas(400, 400);
  createBalls();
  drawScene();
}

function createBalls() {
  balls = [];
  specialIdx = int(random(total));
  for (let i = 0; i < total; i++) {
    let x = random(r, width - r);
    let y = random(r + 40, height - r); // espaço para o placar
    balls.push({
      x: x,
      y: y,
      special: i === specialIdx
    });
  }
}

function drawScene() {
  background(246,114,114);
  // Placar
  fill(0);
  noStroke();
  rect(0, 0, width, 35);
  fill(255);
  textSize(20);
  textAlign(LEFT, CENTER);
  text("Pontos: " + score, 10, 18);
  // Bolas
  for (let b of balls) {
    stroke(139, 0, 0); // borda vermelho escuro
    strokeWeight(3);
    if (b.special) {
      fill(187,3,3); // verde para a especial
    } else {
      fill(255, 0, 0); // vermelho
    }
    ellipse(b.x, b.y, r * 2, r * 2);
  }
}

function mousePressed() {
  for (let b of balls) {
    let d = dist(mouseX, mouseY, b.x, b.y);
    if (d < r && b.special) {
      score++;
      createBalls();
      drawScene();
      return;
    }
  }
}